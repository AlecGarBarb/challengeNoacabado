package com.example.alecyeric.challenge1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import com.android.volley.Request;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;






public class Mate extends AppCompatActivity {

    private final String JSON_URL = "http://numbersapi.com/1" ;

    private JsonObjectRequest request;

    private JSONObject object;

    private TextView txtview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mate);


        txtview = findViewById(R.id.random);

        txtview.setText("Holiii.");

        //jsonrequest();
        jsonIntento2();


    }

    private void jsonIntento2(){

        txtview.setText("Entraste.");


        request = new JsonObjectRequest
                (Request.Method.GET, JSON_URL, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            //JSONArray cardsJSON = response.getJSONArray("cards");
                            object= response.getJSONObject("1");

                            //Toast.makeText(getApplicationContext(), cosito, Toast.LENGTH_LONG).show();

                            txtview.setText(response.toString());



                        }catch(JSONException jsonException){

                            txtview.setText("Error en catch");
                            jsonException.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {


                        Toast.makeText(getApplicationContext(), "No jaló", Toast.LENGTH_LONG).show();
                        txtview.setText("No jalóo.");
                    }
                });




    }


/*
    private void jsonrequest(){

        txtview.setText("Entraste.");

        request = new JsonObjectRequest(Request.Method.GET, JSON_URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    //JSONArray cardsJSON = response.getJSONArray("cards");
                    object= response.getJSONObject("1");

                    //Toast.makeText(getApplicationContext(), cosito, Toast.LENGTH_LONG).show();

                    txtview.setText(object.toString());



                }catch(JSONException jsonException){

                    jsonException.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "Error del servidor", Toast.LENGTH_LONG).show();
                txtview.setText("No jaló");
            }
        });
        //requestQueue = Volley.newRequestQueue(MainActivity.this);
        //requestQueue.add(request);
    }*/


}
